#What I Learned - HW 7

I understood the importance of refactoring and cleaning up your code as you go. This is especially important to do when the code is fresh in your mind, and you know what variables and functions do exactly what. This is made easier when you keep code clean and short and organized in the first place (thank you, jsLint). Although JSLint did make me mad this time, and I'm sorry but I'm just not indenting everything tonight.
